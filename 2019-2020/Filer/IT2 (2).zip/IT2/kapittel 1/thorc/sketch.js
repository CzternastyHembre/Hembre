function setup() {
  // put setup code here
  createCanvas(400, 400);

}
let tid = millis();

function draw() {
  // put drawing code here
  background(200);
  // for (var x = 0; x <= width; x += 10) {
  //   for (var y = 0; y <= height; y += 10) {
  //     // noStroke()
  //     ellipse(x, y, 5, 5);
  //   }}
  text(pen, 0, 0)
}
